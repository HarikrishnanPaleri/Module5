Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_url("4UaGrENHsxJlGDuGo1OIlL3Owp4.woff2", 
		"URL=https://fonts.gstatic.com/s/googlesans/v14/4UaGrENHsxJlGDuGo1OIlL3Owp4.woff2", 
		"Resource=1", 
		"RecContentType=font/woff2", 
		"Referer=https://www.google.com/", 
		"Snapshot=t7.inf", 
		LAST);

	web_url("shopping", 
		"URL=https://encrypted-tbn1.gstatic.com/shopping?q=tbn:ANd9GcQ7xg6V0VpS7yqCscrggFJunl-7YW9VNR2lHHYY6WAwxUcaOYqiw8mTNeW67agVeVuPXcpqY5943ZmqGR5x1v3SqiNXBJlNwQDZImxTnQXsA53X2fJIZxU4", 
		"Resource=1", 
		"RecContentType=image/webp", 
		"Referer=https://www.google.com/", 
		"Snapshot=t8.inf", 
		LAST);

	web_url("shopping_2", 
		"URL=https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcTrR6HifgVtrvmyOtFrpiBscSbzd7Zgwzh51wdWGtT5clMi8QnGKeo7UDgEbzzWywk_75p0BQRbQYIK8quE30IUG8gMTjrECzAnFXJCP-vw1MzPcCUOytI", 
		"Resource=1", 
		"RecContentType=image/webp", 
		"Referer=https://www.google.com/", 
		"Snapshot=t9.inf", 
		LAST);

	web_url("shopping_3", 
		"URL=https://encrypted-tbn1.gstatic.com/shopping?q=tbn:ANd9GcQh1Dyu6Y3GWSVBG1xwq4CLTkMoYbv2CYiA3qnDW03M3-BTwJSLUS54LrdMyeAbqvXKnBRJsVU19Y3tvt5LGb6EKVs4SV0O5iSrXLtP3pxvHbfxNlkeh_ij", 
		"Resource=1", 
		"RecContentType=image/webp", 
		"Referer=https://www.google.com/", 
		"Snapshot=t10.inf", 
		LAST);

	web_set_sockets_option("TLS_SNI", "0");

	web_url("shopping_4", 
		"URL=https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcTeycSHwGsdu_6y2m6Yzl_vBp6FPDhaLBx3bwlq-VsJFvpkN7_6lYOfUBuGoghI5JUUpmON4rV8D6fczViv5HbBfnCIHVlJwTB0GUBDun8", 
		"Resource=1", 
		"RecContentType=image/webp", 
		"Referer=https://www.google.com/", 
		"Snapshot=t11.inf", 
		LAST);

	web_url("shopping_5", 
		"URL=https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcSkuAO9eYMuk0TU3OhXYJPkuNGMuUsHoTIlfzhLs2Nhu-upkzY7SUrnCsQZtOfq-Ih5ODNYJ41z10ik8mthtkRTfcQQPFTlbCvj7WW9k5F6rDmtJCKQnkO6", 
		"Resource=1", 
		"RecContentType=image/webp", 
		"Referer=https://www.google.com/", 
		"Snapshot=t12.inf", 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	web_url("shopping_6", 
		"URL=https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcTpyDJBIA3cLbE5PFncE5DxOLeYpHdLVZXerS8_i9OJx-ZAES8j-UMeLN58ON0elxrBPIZlVufKkj1P_ASGtp3M7vIwjGOskzuM0e4LX4EYn109YX4GAZ8", 
		"Resource=1", 
		"RecContentType=image/webp", 
		"Referer=https://www.google.com/", 
		"Snapshot=t13.inf", 
		LAST);

	web_url("shopping_7", 
		"URL=https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcSkT1M68keF8By-l_5LEN4RofnuDtQVB7OYNG380YAg90X5hbj7MNrdy0s_L0aRK9sM0MUv1SNUMDcZEXQJf8Bdzp-i5WocsdZ8EErWhYCsVwGsjZAsKergOg", 
		"Resource=1", 
		"RecContentType=image/webp", 
		"Referer=https://www.google.com/", 
		"Snapshot=t14.inf", 
		LAST);

	web_url("shopping_8", 
		"URL=https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcRy-dlw_ISW_ees-zMDtVJ0NnyYrJIo_lAD21fLPdER6oFcsHWthzv2c5zmSH1d1wk1bLiur9a3WnBxKxtShvRQmAp8nwIuZEbSEsamVsTLcbrIGWrxppkl", 
		"Resource=1", 
		"RecContentType=image/webp", 
		"Referer=https://www.google.com/", 
		"Snapshot=t15.inf", 
		LAST);

	web_url("shopping_9", 
		"URL=https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcR1-byi9ry85yEfVwaQZZ72HxVtfVsr3n92eoZ7l2WEAvlilvNHiE1iLtfUghofcRbfkIIlGPIeMi7ql6hjeXgR0wC6G-vDYiRpttIm7n0wTy0P1Y3phOpikQ", 
		"Resource=1", 
		"RecContentType=image/webp", 
		"Referer=https://www.google.com/", 
		"Snapshot=t16.inf", 
		LAST);

	web_url("shopping_10", 
		"URL=https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcTbhWNoyg0HbpajqyLlmysji3hZMSL9MGKugznfrf_2eCkzdEZGklM5a7vgRq7MdDr-xzHo8Z_oNztFuY6tVDhv9OwSOg7aVO-gAcj6dUI", 
		"Resource=1", 
		"RecContentType=image/webp", 
		"Referer=https://www.google.com/", 
		"Snapshot=t17.inf", 
		LAST);

	web_url("shopping_11", 
		"URL=https://encrypted-tbn1.gstatic.com/shopping?q=tbn:ANd9GcQlBWsa6tlUDkyeRiXYBneX8ZG7yY54t6vYT_z9_-U7LPqqU9pxej_WqAZCA-g9LpCXgu1YWFG_dazM10015K0Zqf5Tmx0bshv13N9-h-wPgytnKJLylr2dRA", 
		"Resource=1", 
		"RecContentType=image/webp", 
		"Referer=https://www.google.com/", 
		"Snapshot=t18.inf", 
		LAST);

	web_url("shopping_12", 
		"URL=https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcT4RmrgQf_fRiqWQGPaBqZT1NDeiAMe_9TsMIFcpu_6-qExp7g-l5TmWv2oGVla9mjF_K9yXYOTinwnNwq5mC-QTY3ZT8GL_wuk3HSql_k0q7xON3vSQwaY", 
		"Resource=1", 
		"RecContentType=image/webp", 
		"Referer=https://www.google.com/", 
		"Snapshot=t19.inf", 
		LAST);

	web_url("shopping_13", 
		"URL=https://encrypted-tbn1.gstatic.com/shopping?q=tbn:ANd9GcT__-rQVuXZifm1lC5kRP4u5W1tXkF98vCHXuuA4vNdodwvqOUbQn6Z-CgID3euuTEpmtz9vCirUEnxrDD5Vsa01SNY-K6sK-SOdyxNbMM", 
		"Resource=1", 
		"RecContentType=image/webp", 
		"Referer=https://www.google.com/", 
		"Snapshot=t20.inf", 
		LAST);

	web_url("shopping_14", 
		"URL=https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcS3phZFS6d9_okKjgmh8dzGXvNu7QUKp8qS1EEsnoBbmFtvoZejps7s7d98mMCTCBQwiuwZzkEeN0p0xVlbID0kkcLAK4owImaCW5TvCESH2A8tLgAXWT5z7Q", 
		"Resource=1", 
		"RecContentType=image/webp", 
		"Referer=https://www.google.com/", 
		"Snapshot=t21.inf", 
		LAST);

	web_url("shopping_15", 
		"URL=https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcRXxacajnuxGDL6-DGFgOKH8Lqv-Jz4rVX3SMMjYSlMJgClf8haxXmz0S0dI14r2ieWWeqUaP5PKnYFidcT97aC0OgKIIkXyVj9jaN1bMyo", 
		"Resource=1", 
		"RecContentType=image/webp", 
		"Referer=https://www.google.com/", 
		"Snapshot=t22.inf", 
		LAST);

	return 0;
}