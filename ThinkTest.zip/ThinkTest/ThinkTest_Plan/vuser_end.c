vuser_end()
{
	/* logout */
	lr_think_time(64);

	web_url("logout", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/logout", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("logout_2", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/users/logout", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/logout", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_url("thinking-tester-contact-list.herokuapp.com_2", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/logout", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("TLS_SNI", "0");

	web_url("login.js", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/js/login.js", 
		"TargetFrame=", 
		"Resource=1", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/", 
		"Snapshot=t12.inf", 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	web_custom_request("reports", 
		"URL=https://nel.heroku.com/reports?ts=1707729549&sid=af571f24-03ee-46d1-9f90-ab9030c2c74c&s=Kcs4XW7BR%2Fy6AlQ1erNz%2FFnndvi4XvqrCauHT6JZrFs%3D", 
		"Method=OPTIONS", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("reports_2", 
		"URL=https://nel.heroku.com/reports?ts=1707729549&sid=af571f24-03ee-46d1-9f90-ab9030c2c74c&s=Kcs4XW7BR%2Fy6AlQ1erNz%2FFnndvi4XvqrCauHT6JZrFs%3D", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"EncType=application/reports+json", 
		"Body=[{\"age\":1,\"body\":{\"elapsed_time\":497,\"method\":\"GET\",\"phase\":\"application\",\"protocol\":\"http/1.1\",\"referrer\":\"https://thinking-tester-contact-list.herokuapp.com/logout\",\"sampling_fraction\":0.005,\"server_ip\":\"3.229.186.102\",\"status_code\":304,\"type\":\"ok\"},\"type\":\"network-error\",\"url\":\"https://thinking-tester-contact-list.herokuapp.com/img/thinkingTesterIcon.png\",\"user_agent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like "
		"Gecko) Chrome/121.0.0.0 Safari/537.36\"}]", 
		LAST);

	return 0;
}